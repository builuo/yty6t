const ffmpeg = require('fluent-ffmpeg');
const chokidar = require('chokidar');

ffmpeg('./v/test.3gp')
    .videoBitrate(1024)
    .aspect('16:9')
    .size('50%')
    .fps(64)
    .format('mp4')
    .on('end', function () {
        console.log('成功');
    })
    .on('error', function (err) {
        console.log('失败: ' + err.message);
    })
    .save(`./o/o${Date.now()}.mp4`);

















































// const fs = require('fs')
// const Path = require('path');
// const exitArr = ['.avi', '.3gp', '.mov', '.mkv', '.mp4', '.rm', '.rmvb', '.vob', '.wmv']
// const watcher = chokidar.watch('v',
//     {
//         ignored:
//             /[\/\\]\./, persistent: true
//     });

// const log = console.log.bind(console);
// function isFileExisted(path_way) {
//     return new Promise((resolve, reject) => {
//         fs.access(path_way, (err) => {
//             if (err) {
//                 reject(false);//"不存在"
//             } else {
//                 resolve(true);//"存在"
//             }
//         })
//     })
// };

// watcher
//     .on('add',
//         async function (path) {
//             if (exitArr.includes(Path.extname(path))) {
//                 let isCunzai = await isFileExisted(path)
//                 if (isCunzai) {
//                     ffmpeg('./v/a.avi')
//                         .videoBitrate(1024)
//                         .aspect('16:9')
//                         .size('50%')
//                         .fps(64)
//                         .format('mp4')
//                         .on('end', function () {
//                             console.log('成功');
//                         })
//                         .on('error', function (err) {
//                             console.log('失败: ' + err.message);
//                         })
//                         .save(`./output/o${Date.now()}.mp4`);
//                 } else {
//                     console.log('文件名称重复')
//                 }
//                 console.log(Path.extname(path), '11111111')
//             }

//             log('File', path, 'hasbeen added');
//         })
//     .on('addDir',
//         function (path) {
//             log('Directory',
//                 path, 'hasbeen added');
//         })
//     .on('change',
//         function (path) {
//             log('File',
//                 path, 'hasbeen changed');
//         })
//     .on('unlink',
//         function (path) {
//             log('File',
//                 path, 'hasbeen removed');
//         })
//     .on('unlinkDir',
//         function (path) {
//             log('Directory',
//                 path, 'hasbeen removed');
//         })
//     .on('error',
//         function (error) {
//             log('Error happened',
//                 error);
//         })
//     .on('ready',
//         function () {
//             log('Initialscan complete. Ready for changes.');
//         })
//     .on('raw',
//         function (event,
//             path, details) {
//             log('Rawevent info:',
//                 event, path, details);
//         })


